# Replace YOUR_MYSQL_PASSWORD with your local MySQL root password.
DB_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "YOUR_MYSQL_PASSWORD",
    "database": "recruitment_placement",
}
