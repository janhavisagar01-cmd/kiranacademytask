def check_eligibility(candidate, job):
    reasons = []
    if float(candidate["percentage"]) < float(job["minimum_percentage"]):
        reasons.append(f'percentage below {job["minimum_percentage"]}%')
    if int(candidate["backlogs"]) > int(job["maximum_backlogs"]):
        reasons.append(f'backlogs exceed {job["maximum_backlogs"]}')
    required = {s.strip().lower() for s in (job.get("required_skills") or "").split(",") if s.strip()}
    available = {s.strip().lower() for s in (candidate.get("skills") or "").split(",") if s.strip()}
    missing = required - available
    if missing:
        reasons.append("missing skills: " + ", ".join(sorted(missing)))
    return not reasons, reasons
